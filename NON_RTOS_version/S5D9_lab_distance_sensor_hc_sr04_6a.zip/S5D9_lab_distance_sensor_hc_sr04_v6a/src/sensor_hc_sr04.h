/*
 * sensor_hc_sr04.h
 *
 *  Created on: Feb 6, 2018
 *      Author: mikel
 *
 *      Description: Constants, global variables and function declaraiions.
 *
 */


#ifndef SENSOR_HC_SR04_H_
#define SENSOR_HC_SR04_H_


// Set Pin name.
#define SENSOR_TRIGGER_PIN  IOPORT_PORT_02_PIN_03   // out pin
#define SENSOR_ECHO_PIN     IOPORT_PORT_02_PIN_05   // in pin




// Define the number of counts per millisecond (1 count per clock tick, clock rate is 120MHz for the S5D9 IOT board)
// So there are 120E6 ticks per second.
// Divide by 1000 to get ticks / microsecond
#define COUNTS_PER_MICROSECOND  (120E6 / 1000000)

// Counts per msec depends on the timer clock (FCLKA)
#define FIND_DISTANCE(x)  ( ((x) / COUNTS_PER_MICROSECOND) / (59) )


// Trigger pulse width in usec
#define TRIGPULSEWIDTH  10      // 10 usec
#define MAXECHOTIME     60000   // 60 msec

// Global External Variables to share with other thread

// Global variables (Main and ISR)
bool g_time_start_flag;           // flag enabled to begin the detection of the echo signal
bool g_time_end_flag;             // flag enabled when the falling edge of the echo signal is detected.
timer_size_t g_echo_start_time;   // the time at the rising edge of the echo signal.
timer_size_t g_echo_end_time;     // the time at the falling edge of the echo signal.

ssp_err_t hc_sr04_initialize_timer (void);
ssp_err_t hc_sr04_initialize_interrupt (void);
uint32_t hc_sr04_get_distance(void);
void echo_callback(external_irq_callback_args_t * p_args);

#endif /* SENSOR_HC_SR04_H_ */
