#include "system_thread.h"

/* System Thread entry function */
void system_thread_entry(void)
{
    /* TODO: add your own code here */
    while (1)
    {
        tx_thread_sleep (1);
    }
}
