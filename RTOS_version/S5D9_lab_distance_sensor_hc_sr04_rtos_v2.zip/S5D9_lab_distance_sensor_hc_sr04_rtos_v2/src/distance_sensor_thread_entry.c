#include "distance_sensor_thread.h"
#include "sensor_hc_sr04.h"

#define GREEN_LED_PIN       IOPORT_PORT_01_PIN_02   // out pin
#define YEL_LED_PIN         IOPORT_PORT_01_PIN_03   // out pin
#define RED_LED_PIN         IOPORT_PORT_01_PIN_13   // out pin

// Onboard LED on/off states
#define LED_ON 1
#define LED_OFF 0

/* Distance Sensor Thread entry function */
void distance_sensor_thread_entry(void) {
    // API return status
    ssp_err_t   err;
    uint32_t    distance;       // distance value from the sensor


    err = hc_sr04_initialize_timer();
    if (err != SSP_SUCCESS)
    {
        g_ioport.p_api->pinWrite(RED_LED_PIN, LED_ON);  // turn on red led for error
        while (1);
    } else {
        g_ioport.p_api->pinWrite(GREEN_LED_PIN, LED_ON);  // turn on green led for success
    }
    err = hc_sr04_initialize_interrupt();
    if (err != SSP_SUCCESS)
    {
        g_ioport.p_api->pinWrite(RED_LED_PIN, LED_ON);  // turn on red led for error
        while (1);
    } else {
        g_ioport.p_api->pinWrite(GREEN_LED_PIN, LED_ON);  // turn on green led for success
    }

    while (1) {
        distance = hc_sr04_get_distance();
        if (distance > 1) {
            g_ioport.p_api->pinWrite(YEL_LED_PIN, LED_OFF);  // turn off yellow led for error
        } else {
            g_ioport.p_api->pinWrite(YEL_LED_PIN, LED_ON);  // turn on Yellow led for error
        }
        tx_thread_sleep (1);

    } // while (1)
}
