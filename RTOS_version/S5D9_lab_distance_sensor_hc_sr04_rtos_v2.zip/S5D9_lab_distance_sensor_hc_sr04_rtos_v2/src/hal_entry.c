/*

    Project: Distance Sensor HC SR04
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    2/6/18

    SSP version: 1.30
    E2 Studio version: 5.4.0.023

    Description:  Generate the trigger signal (Trigger) and then measure the width of the echo signal from
                  the sensor.   Time out will expire if the echo signal does not appear within 60msec.

    Port (PMOD)

    pin 1 P2_5 (Echo Pin)  IRQ01 (channel 1) 5V Tolerant pin
    pin 2 P2_3 (Trigger Pin) GPIO output
    pin 5 Gnd
    pin 6 VCC (Use J6 jumper for 5V selection)

    LED1 Green = On if the timer and interrupt drivers are successfully opened.
    LED2 Red = On if the timer and interrupt drivers cannot be opened.

    Calculation for distance :   Distance = (Echo pulse width (usec) x (Speed of light) (m/sec)) / 2 (round trip)
                                          = (Echo pulse width (usec) x sec/ 1e6 sec x 340 m/sec x 100 cm/m) /2
                                          = Echo pulse width  (usec) / (2e6 / 340 x 100 cm / usec)
                                          = Echo pulse width (usec) / 58.8 usec / cm
                                          = in (cm)

    version 1: 1. Measure the pulse width of the echo signal.
    version 2: 1. Convert the pulse width to the actual distance.
               2. Exception handling when the echo pulse is greater than 60ms.  Add wait for the echo
               signal to go low.
    version 3: created sensor_hc_sr04.h and sensor_hc_sr04.c.  Need #include "hal_data.h" in sensor_hc_sr04.c
    version 4: created sensor_hc_sr04.h/c by making new functions.  Remove the
               while loop since we only make one measurement instead of periodical
               measurements.
    version 5: Turn on yellow led whenever distance_cm is 0.

    version 6a: (new) - use timer interrupt for accuracy and get the code ready for RTOS modification

    RTOS
    version 1: copy from ver 6a.  Create distance_sensor_thread.

*/

/* HAL-only entry function */
#include "hal_data.h"

#define GREEN_LED_PIN       IOPORT_PORT_01_PIN_02   // out pin
#define YEL_LED_PIN         IOPORT_PORT_01_PIN_03   // out pin
#define RED_LED_PIN         IOPORT_PORT_01_PIN_13   // out pin

// Onboard LED on/off states
#define LED_ON 1
#define LED_OFF 0



void hal_entry(void)
{
    while (1) {
        tx_thread_sleep (1);
    } // while (1)
}


