/*
 * sensor_hc_sr04.c
 *
 *  Created on: Feb 6, 2018
 *      Author: mikel
 */

#include "distance_sensor_thread.h"
#include "sensor_hc_sr04.h"

volatile bool g_timerdone;

void timer_delay_us(timer_size_t   const delay);

ssp_err_t hc_sr04_initialize_timer (void) {

    // Open the timer driver
    return(g_trig_timer.p_api->open (g_trig_timer.p_ctrl, g_trig_timer.p_cfg));

}

ssp_err_t hc_sr04_initialize_interrupt (void) {

    // Open the interrupt driver
    return (g_echo_interrupt.p_api->open(g_echo_interrupt.p_ctrl,g_echo_interrupt.p_cfg));
}

// Return the distance value in cm.
uint32_t hc_sr04_get_distance(void){

    // Local Variables

    // Variables to hold time value
     timer_size_t timedelay = 0;     // Time delay (in uS) for Trigger on and off time
     timer_size_t echo_pulse_width;  // the width = the end time - the start time.

     ioport_level_t echo_pin_value;  // used to check echo pin before sending
                                     // the trigger pulse.
     uint32_t     distance_cm = 0;       // distance calculated from the pulse width of the echo signal.

     // Initialization
     g_time_start_flag = false;
     g_time_end_flag = false;

     // De-assert Trigger low
     g_ioport.p_api->pinWrite(SENSOR_TRIGGER_PIN, IOPORT_LEVEL_LOW);  // trigger (pin 2)
     timedelay = TRIGPULSEWIDTH;  // pulse on time
     timer_delay_us(timedelay);

     // Generate a short Trigger pulse
     g_ioport.p_api->pinWrite(SENSOR_TRIGGER_PIN, IOPORT_LEVEL_HIGH);
     timedelay = TRIGPULSEWIDTH;  // pulse on time
     timer_delay_us(timedelay);

     // De-assert Trigger low
     g_ioport.p_api->pinWrite(SENSOR_TRIGGER_PIN, IOPORT_LEVEL_LOW);  // trigger (pin 2)
     timedelay = MAXECHOTIME;  // pulse off time
     g_time_start_flag = true; // Enable the start flag for ISR to detect the echo signal
     g_time_end_flag = false;

     timer_delay_us(timedelay);

     if (true == g_time_start_flag && true == g_time_end_flag) {
         echo_pulse_width = g_echo_end_time - g_echo_start_time;
         distance_cm = FIND_DISTANCE(echo_pulse_width);
     } else {
         echo_pulse_width = (timer_size_t)-1; // error
         distance_cm = 0;   // indicate error
     }

     // If echo pin is still high, it is required to wait for the signal
     // to return to zero before sending the trigger pulse.
     do {
          g_ioport.p_api->pinRead(SENSOR_ECHO_PIN, &echo_pin_value);
     } while ((IOPORT_LEVEL_HIGH == echo_pin_value));

     return distance_cm;
 }


void timer_delay_us(timer_size_t   const delay){
    g_timerdone = false;
    g_trig_timer.p_api->periodSet(g_trig_timer.p_ctrl,delay,TIMER_UNIT_PERIOD_USEC);
    g_trig_timer.p_api->start(g_trig_timer.p_ctrl);   // required that autostart = false.
    if (MAXECHOTIME == delay)
        tx_thread_sleep (MAXECHOTXDELAY);  // A long wait but allows other threads to run
    while (1) {
        if (g_timerdone) {
            break;
        }
    }
}




void distance_sensor_timer_callback(timer_callback_args_t * p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);

    g_trig_timer.p_api->stop(g_trig_timer.p_ctrl);
    g_trig_timer.p_api->reset(g_trig_timer.p_ctrl);
    g_timerdone = true;
}


// update global variables: g_echo_start_time, g_echo_end_time, g_time_end_flag
void echo_callback(external_irq_callback_args_t * p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);

    ioport_level_t p_pin_value;
    g_ioport.p_api->pinRead(SENSOR_ECHO_PIN, &p_pin_value);
    if (true == g_time_start_flag && false == g_time_end_flag){
        if (IOPORT_LEVEL_HIGH == p_pin_value) {
            g_trig_timer.p_api->counterGet(g_trig_timer.p_ctrl, &g_echo_start_time);
        } else {
            g_trig_timer.p_api->counterGet(g_trig_timer.p_ctrl, &g_echo_end_time);
            g_time_end_flag = true;
        }
    }
}

